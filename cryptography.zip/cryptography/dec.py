import os
from crpytography.fernet import Fernet

files_to = []

for file in os.listdir():  # do or statemtns to match files that dont need encrpy
    if file == "yo.py":
        continue
    if os.path.isfile(file):
        files_to.append(file)

print(files_to)

with open("speckey.key", "rb") as speckey:
    secret_key = speckey.read()

for file in files_to:
    with open(file, "rb") as specfile:
        contents = specfile.read()
    contents_dec = Fernet(secret_key).decrypt(contents)

    with open(file, "wb") as specfile:
        specfile.write(contents_dec)
